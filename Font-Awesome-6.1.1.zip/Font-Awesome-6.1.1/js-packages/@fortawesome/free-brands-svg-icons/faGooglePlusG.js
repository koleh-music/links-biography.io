'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'google-plus-g';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f0d5';
var svgPathData = 'M386.1 228.5c1.834 9.692 3.143 19.38 3.143 31.96C389.2 370.2 315.6 448 204.8 448c-106.1 0-192-85.92-192-192s85.92-192 192-192c51.86 0 95.08 18.86 128.6 50.29l-52.13 50.03c-14.15-13.62-39.03-29.6-76.49-29.6-65.48 0-118.9 54.22-118.9 121.3 0 67.06 53.44 121.3 118.9 121.3 75.96 0 104.5-54.74 108.1-82.77H204.8v-66.01h181.3zm185.4 6.437V179.2h-56v55.73h-55.73v56h55.73v55.73h56v-55.73H627.2v-56h-55.73z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faGooglePlusG = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;