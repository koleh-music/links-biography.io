'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'fulcrum';
var width = 320;
var height = 512;
var aliases = [];
var unicode = 'f50b';
var svgPathData = 'M95.75 164.1l-35.38 43.55L25 164.1l35.38-43.55zM144.2 0l-20.54 198.2L72.72 256l51 57.82L144.2 512V300.9L103.2 256l41.08-44.89zm79.67 164.1l35.38 43.55 35.38-43.55-35.38-43.55zm-48.48 47L216.5 256l-41.08 44.89V512L196 313.8 247 256l-51-57.82L175.4 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFulcrum = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;